<?php
/**
* PHP Mikrotik Billing (https://ibnux.github.io/phpmixbill/)


* @copyright	Copyright (C) 2014-2015 PHP Mikrotik Billing
* @license		GNU General Public License version 2 or later; see LICENSE.txt

* FULL FEATURED CREATED / ADDED BY : 
* EMAIL		: EFDIKA.DOANK@GMAIL.COM
* FACEBOOK	: HTTPS://WWW.FACEBOOK.COM/EF.DOANK
* MOBILE	: +62 813 6446 0755

**/

header('location: ../index.php?page=admin/');