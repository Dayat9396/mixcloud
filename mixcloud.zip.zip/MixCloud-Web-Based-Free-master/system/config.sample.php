<?php
	$db_host	    = 'localhost';
	$db_user        = '';
	$db_password	= '';
	$db_name	    = '';
	define('APP_URL', 'http://x.x.x.x');
	$_app_stage = 'Live';