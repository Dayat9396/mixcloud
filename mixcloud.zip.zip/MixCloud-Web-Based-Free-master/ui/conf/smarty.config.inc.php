<?php
//$smarty->caching = false;
//$smarty->force_compile = true;
?>